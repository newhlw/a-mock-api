import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useNodeState } from './useNodeState';
import { nodeStyles } from './nodeStyles';

export const InputNode = ({ id, data }) => {
  const [currName, setCurrName] = useNodeState(id, 'inputName', data?.inputName || id.replace('customInput-', 'input_'));
  const [inputType, setInputType] = useNodeState(id, 'inputType', data.inputType || 'Text');

  return (
    <BaseNode
      title="Input"
      handles={[{ id: `${id}-value`, type: 'source', position: Position.Right }]}
    >
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Value</span>
        <input style={nodeStyles.input} type="text" value={currName} onChange={(e) => setCurrName(e.target.value)} />
      </div>
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Type</span>
        <select style={nodeStyles.select} value={inputType} onChange={(e) => setInputType(e.target.value)}>
          <option value="Text">Text</option>
          <option value="File">File</option>
        </select>
      </div>
    </BaseNode>
  );
}
