import { useMemo } from 'react';
import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useNodeState } from './useNodeState';
import { nodeStyles } from './nodeStyles';

const parseVariables = (text) => {
  const matches = text.match(/\{\{(\w+)\}\}/g) || [];
  const vars = matches.map(m => m.slice(2, -2));
  return [...new Set(vars)];
};

export const TextNode = ({ id, data }) => {
  const [currText, setCurrText] = useNodeState(id, 'text', data?.text || '{{input}}');

  const variables = useMemo(() => parseVariables(currText), [currText]);

  const nodeWidth = Math.max(220, Math.min(400, 100 + currText.length * 5));
  const nodeHeight = Math.max(100, Math.min(250, 100 + variables.length * 25));

  const handles = [
    { id: `${id}-output`, type: 'source', position: Position.Right },
    ...variables.map((v, i) => ({
      id: `${id}-${v}`,
      type: 'target',
      position: Position.Left,
      label: v,
      style: {
        top: `${((i + 1) / (variables.length + 1)) * 100}%`,
      },
    })),
  ];

  return (
    <BaseNode
      title="Text"
      handles={handles}
      style={{ width: nodeWidth, minHeight: nodeHeight }}
    >
      <div style={nodeStyles.textareaWrapper}>
        <textarea
          style={{ ...nodeStyles.textarea, minHeight: `${Math.max(50, nodeHeight - 60)}px` }}
          value={currText}
          onChange={(e) => setCurrText(e.target.value)}
          placeholder="Type text or {{variable}}..."
        />
      </div>
      {variables.length > 0 && (
        <div style={nodeStyles.variableTags}>
          {variables.map(v => (
            <span key={v} style={nodeStyles.variableTag}>{v}</span>
          ))}
        </div>
      )}
    </BaseNode>
  );
}
