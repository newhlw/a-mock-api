import { useState, useEffect } from 'react';
import { useStore } from '../store';

export const useNodeState = (id, fieldName, defaultValue) => {
  const [value, setValue] = useState(defaultValue);
  const updateNodeField = useStore((s) => s.updateNodeField);

  useEffect(() => {
    updateNodeField(id, fieldName, value);
  }, [id, fieldName, value, updateNodeField]);

  return [value, setValue];
};
