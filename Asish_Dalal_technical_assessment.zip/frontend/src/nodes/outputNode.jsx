import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useNodeState } from './useNodeState';
import { nodeStyles } from './nodeStyles';

export const OutputNode = ({ id, data }) => {
  const [currName, setCurrName] = useNodeState(id, 'outputName', data?.outputName || id.replace('customOutput-', 'output_'));
  const [outputType, setOutputType] = useNodeState(id, 'outputType', data.outputType || 'Text');

  return (
    <BaseNode
      title="Output"
      handles={[{ id: `${id}-value`, type: 'target', position: Position.Left }]}
    >
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Name</span>
        <input style={nodeStyles.input} type="text" value={currName} onChange={(e) => setCurrName(e.target.value)} />
      </div>
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Type</span>
        <select style={nodeStyles.select} value={outputType} onChange={(e) => setOutputType(e.target.value)}>
          <option value="Text">Text</option>
          <option value="File">Image</option>
        </select>
      </div>
    </BaseNode>
  );
}
