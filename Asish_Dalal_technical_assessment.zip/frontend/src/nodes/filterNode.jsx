import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useNodeState } from './useNodeState';
import { nodeStyles } from './nodeStyles';

export const FilterNode = ({ id, data }) => {
  const [condition, setCondition] = useNodeState(id, 'condition', data?.condition || 'contains');

  return (
    <BaseNode
      title="Filter"
      handles={[
        { id: `${id}-input`, type: 'target', position: Position.Left },
        { id: `${id}-pass`, type: 'source', position: Position.Right, style: { top: `${100/3}%` } },
        { id: `${id}-fail`, type: 'source', position: Position.Right, style: { top: `${200/3}%` } },
      ]}
    >
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Condition</span>
        <select style={nodeStyles.select} value={condition} onChange={(e) => setCondition(e.target.value)}>
          <option value="contains">Contains</option>
          <option value="equals">Equals</option>
          <option value="greater">Greater Than</option>
          <option value="less">Less Than</option>
        </select>
      </div>
    </BaseNode>
  );
}
