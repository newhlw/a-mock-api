import { InputNode } from './inputNode';
import { OutputNode } from './outputNode';
import { LLMNode } from './llmNode';
import { TextNode } from './textNode';
import { MathNode } from './mathNode';
import { FilterNode } from './filterNode';
import { MergeNode } from './mergeNode';
import { SplitNode } from './splitNode';
import { TransformNode } from './transformNode';

export const nodeConfig = {
  customInput: {
    component: InputNode,
    label: 'Input',
    type: 'customInput',
  },
  llm: {
    component: LLMNode,
    label: 'LLM',
    type: 'llm',
  },
  customOutput: {
    component: OutputNode,
    label: 'Output',
    type: 'customOutput',
  },
  text: {
    component: TextNode,
    label: 'Text',
    type: 'text',
  },
  math: {
    component: MathNode,
    label: 'Math',
    type: 'math',
  },
  filter: {
    component: FilterNode,
    label: 'Filter',
    type: 'filter',
  },
  merge: {
    component: MergeNode,
    label: 'Merge',
    type: 'merge',
  },
  split: {
    component: SplitNode,
    label: 'Split',
    type: 'split',
  },
  transform: {
    component: TransformNode,
    label: 'Transform',
    type: 'transform',
  },
};

// Auto-generated from nodeConfig
export const nodeTypes = Object.fromEntries(
  Object.entries(nodeConfig).map(([key, config]) => [key, config.component])
);

export const toolbarNodes = Object.values(nodeConfig).map(({ type, label }) => ({
  type,
  label,
}));
