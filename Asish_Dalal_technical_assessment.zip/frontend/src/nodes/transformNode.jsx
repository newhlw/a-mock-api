import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useNodeState } from './useNodeState';
import { nodeStyles } from './nodeStyles';

export const TransformNode = ({ id, data }) => {
  const [transform, setTransform] = useNodeState(id, 'transform', data?.transform || 'uppercase');

  return (
    <BaseNode
      title="Transform"
      handles={[
        { id: `${id}-input`, type: 'target', position: Position.Left },
        { id: `${id}-output`, type: 'source', position: Position.Right },
      ]}
    >
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Operation</span>
        <select style={nodeStyles.select} value={transform} onChange={(e) => setTransform(e.target.value)}>
          <option value="uppercase">Uppercase</option>
          <option value="lowercase">Lowercase</option>
          <option value="reverse">Reverse</option>
          <option value="trim">Trim</option>
        </select>
      </div>
    </BaseNode>
  );
}
