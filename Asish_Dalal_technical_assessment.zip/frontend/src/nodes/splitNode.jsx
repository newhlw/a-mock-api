import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useNodeState } from './useNodeState';
import { nodeStyles } from './nodeStyles';

export const SplitNode = ({ id, data }) => {
  const [mode, setMode] = useNodeState(id, 'mode', data?.mode || 'copy');

  return (
    <BaseNode
      title="Split"
      handles={[
        { id: `${id}-input`, type: 'target', position: Position.Left },
        { id: `${id}-out1`, type: 'source', position: Position.Right, style: { top: `${100/3}%` } },
        { id: `${id}-out2`, type: 'source', position: Position.Right, style: { top: `${200/3}%` } },
      ]}
    >
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Mode</span>
        <select style={nodeStyles.select} value={mode} onChange={(e) => setMode(e.target.value)}>
          <option value="copy">Copy</option>
          <option value="alternate">Alternate</option>
          <option value="split">Half/Half</option>
        </select>
      </div>
    </BaseNode>
  );
}
