import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useNodeState } from './useNodeState';
import { nodeStyles } from './nodeStyles';

export const MathNode = ({ id, data }) => {
  const [operation, setOperation] = useNodeState(id, 'operation', data?.operation || '+');

  return (
    <BaseNode
      title="Math"
      handles={[
        { id: `${id}-a`, type: 'target', position: Position.Left, style: { top: `${100/3}%` } },
        { id: `${id}-b`, type: 'target', position: Position.Left, style: { top: `${200/3}%` } },
        { id: `${id}-result`, type: 'source', position: Position.Right },
      ]}
    >
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Operation</span>
        <select style={nodeStyles.select} value={operation} onChange={(e) => setOperation(e.target.value)}>
          <option value="+">Add (+)</option>
          <option value="-">Subtract (-)</option>
          <option value="*">Multiply (×)</option>
          <option value="/">Divide (÷)</option>
        </select>
      </div>
    </BaseNode>
  );
}
