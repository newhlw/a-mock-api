import { Handle, Position } from 'reactflow';
import { nodeStyles } from './nodeStyles';

export const BaseNode = ({ title, handles = [], children, style = {} }) => {
  const targetHandles = handles.filter(h => h.type === 'target');
  const sourceHandles = handles.filter(h => h.type === 'source');

  return (
    <div style={{ ...nodeStyles.container, ...style }}>
      {targetHandles.map((h) => (
        <Handle
          key={h.id}
          type="target"
          position={h.position || Position.Left}
          id={h.id}
          style={h.style || {}}
        />
      ))}
      <div style={nodeStyles.title}>{title}</div>
      <div style={nodeStyles.content}>{children}</div>
      {sourceHandles.map((h) => (
        <Handle
          key={h.id}
          type="source"
          position={h.position || Position.Right}
          id={h.id}
          style={h.style || {}}
        />
      ))}
    </div>
  );
};
