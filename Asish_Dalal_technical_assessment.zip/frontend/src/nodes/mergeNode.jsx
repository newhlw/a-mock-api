import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useNodeState } from './useNodeState';
import { nodeStyles } from './nodeStyles';

export const MergeNode = ({ id, data }) => {
  const [strategy, setStrategy] = useNodeState(id, 'strategy', data?.strategy || 'concat');

  return (
    <BaseNode
      title="Merge"
      handles={[
        { id: `${id}-in1`, type: 'target', position: Position.Left, style: { top: `${100/3}%` } },
        { id: `${id}-in2`, type: 'target', position: Position.Left, style: { top: `${200/3}%` } },
        { id: `${id}-merged`, type: 'source', position: Position.Right },
      ]}
    >
      <div style={nodeStyles.label}>
        <span style={nodeStyles.labelText}>Strategy</span>
        <select style={nodeStyles.select} value={strategy} onChange={(e) => setStrategy(e.target.value)}>
          <option value="concat">Concatenate</option>
          <option value="zip">Zip</option>
          <option value="average">Average</option>
        </select>
      </div>
    </BaseNode>
  );
}
