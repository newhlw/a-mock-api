import { useState } from 'react';
import { useStore } from './store';
import { shallow } from 'zustand/shallow';

const selector = (state) => ({
  nodes: state.nodes,
  edges: state.edges,
});

export const SubmitButton = ({ onOutput }) => {
  const { nodes, edges } = useStore(selector, shallow);
  const [isRunning, setIsRunning] = useState(false);

  const handleSubmit = async () => {
    const formData = new URLSearchParams();
    formData.append('nodes', JSON.stringify(nodes));
    formData.append('edges', JSON.stringify(edges));

    try {
      const res = await fetch('http://localhost:8000/pipelines/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData,
      });
      const data = await res.json();
      alert(
        `Nodes: ${data.num_nodes}\nEdges: ${data.num_edges}\nIs DAG: ${data.is_dag}`
      );
    } catch (err) {
      alert('Failed to submit pipeline: ' + err.message);
    }
  };

  const handleRun = async () => {
    setIsRunning(true);
    const formData = new URLSearchParams();
    formData.append('nodes', JSON.stringify(nodes));
    formData.append('edges', JSON.stringify(edges));

    try {
      const res = await fetch('http://localhost:8000/pipelines/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData,
      });
      const data = await res.json();
      if (onOutput) onOutput(data);
    } catch (err) {
      if (onOutput) {
        onOutput({
          success: false,
          result: null,
          node_outputs: {},
          execution_time: 0,
          errors: ['Failed to connect to backend: ' + err.message],
        });
      }
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="submit-section">
      <span className="submit-info">
        {nodes.length} nodes · {edges.length} edges
      </span>
      <div style={{ display: 'flex', gap: '10px' }}>
        <button className="submit-btn" type="button" onClick={handleSubmit}>
          Analyze
        </button>
        <button
          className="run-btn"
          type="button"
          onClick={handleRun}
          disabled={isRunning}
        >
          {isRunning ? 'Running...' : 'Run Pipeline'}
        </button>
      </div>
    </div>
  );
}
