import { useState } from 'react';

export const OutputPanel = ({ output, onClear }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  if (!output) return null;

  return (
    <div style={styles.panel}>
      <div style={styles.header}>
        <span style={styles.title}>Output</span>
        <div style={styles.headerButtons}>
          <button style={styles.expandBtn} onClick={() => setIsExpanded(!isExpanded)}>
            {isExpanded ? '−' : '+'}
          </button>
          <button style={styles.clearBtn} onClick={onClear}>Clear</button>
        </div>
      </div>
      {isExpanded && (
        <div style={styles.content}>
          {output.success ? (
            <div style={styles.successBadge}>✓ Executed successfully</div>
          ) : (
            <div style={styles.errorBadge}>✗ Execution failed</div>
          )}

          {output.result !== null && output.result !== undefined && output.result !== '' ? (
            <div style={styles.resultSection}>
              <span style={styles.resultLabel}>Result:</span>
              <div style={styles.resultValue}>{String(output.result)}</div>
            </div>
          ) : output.success ? (
            <div style={styles.noOutput}>
              Pipeline executed but no Output node found. Add an Output node to see results.
            </div>
          ) : null}

          {output.errors && output.errors.length > 0 && (
            <div style={styles.errorSection}>
              {output.errors.map((err, i) => (
                <div key={i} style={styles.errorText}>{err}</div>
              ))}
            </div>
          )}

          <div style={styles.meta}>
            <span>Execution time: {output.execution_time}s</span>
          </div>

          {output.node_outputs && Object.keys(output.node_outputs).length > 0 && (
            <div style={styles.detailsSection}>
              <span style={styles.detailsLabel}>Node Outputs:</span>
              {Object.entries(output.node_outputs).map(([id, val]) => (
                <div key={id} style={styles.nodeOutput}>
                  <span style={styles.nodeId}>{id}:</span>
                  <span style={styles.nodeVal}>{val}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const styles = {
  panel: {
    background: '#1a1f2e',
    borderTop: '1px solid #2d3548',
    maxHeight: '300px',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 16px',
    borderBottom: '1px solid #2d3548',
  },
  title: {
    color: '#e2e5f1',
    fontSize: '13px',
    fontWeight: 600,
    letterSpacing: '0.3px',
  },
  headerButtons: {
    display: 'flex',
    gap: '8px',
    alignItems: 'center',
  },
  expandBtn: {
    background: 'none',
    border: '1px solid #4a5568',
    color: '#e2e5f1',
    width: '24px',
    height: '24px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  clearBtn: {
    background: 'none',
    border: '1px solid #4a5568',
    color: '#e2e5f1',
    padding: '4px 12px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '12px',
  },
  content: {
    padding: '12px 16px',
    overflowY: 'auto',
    color: '#e2e5f1',
    fontSize: '13px',
  },
  successBadge: {
    display: 'inline-block',
    padding: '4px 10px',
    background: 'rgba(34, 197, 94, 0.15)',
    color: '#22c55e',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 500,
    marginBottom: '12px',
  },
  errorBadge: {
    display: 'inline-block',
    padding: '4px 10px',
    background: 'rgba(239, 68, 68, 0.15)',
    color: '#ef4444',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 500,
    marginBottom: '12px',
  },
  resultSection: {
    marginBottom: '12px',
  },
  resultLabel: {
    fontSize: '11px',
    color: '#9ca3af',
    fontWeight: 500,
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  resultValue: {
    marginTop: '6px',
    padding: '10px 12px',
    background: '#0f1219',
    borderRadius: '6px',
    fontFamily: 'monospace',
    fontSize: '13px',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word',
    border: '1px solid #2d3548',
  },
  errorSection: {
    marginBottom: '12px',
  },
  errorText: {
    padding: '8px 10px',
    background: 'rgba(239, 68, 68, 0.1)',
    borderRadius: '4px',
    color: '#fca5a5',
    fontSize: '12px',
    marginBottom: '4px',
  },
  meta: {
    fontSize: '11px',
    color: '#6b7280',
    marginBottom: '12px',
  },
  detailsSection: {
    borderTop: '1px solid #2d3548',
    paddingTop: '12px',
  },
  detailsLabel: {
    fontSize: '11px',
    color: '#9ca3af',
    fontWeight: 500,
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    display: 'block',
    marginBottom: '8px',
  },
  nodeOutput: {
    display: 'flex',
    gap: '8px',
    marginBottom: '4px',
    fontSize: '12px',
  },
  nodeId: {
    color: '#4f6ef7',
    fontWeight: 500,
    minWidth: '120px',
  },
  nodeVal: {
    color: '#9ca3af',
    fontFamily: 'monospace',
  },
  noOutput: {
    padding: '10px 12px',
    background: 'rgba(245, 158, 11, 0.1)',
    borderRadius: '6px',
    color: '#f59e0b',
    fontSize: '12px',
    marginBottom: '12px',
  },
};
