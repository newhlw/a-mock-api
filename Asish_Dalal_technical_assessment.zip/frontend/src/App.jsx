import { useState } from 'react';
import { PipelineToolbar } from './toolbar';
import { PipelineUI } from './ui';
import { SubmitButton } from './submit';
import { OutputPanel } from './outputPanel';

function App() {
  const [output, setOutput] = useState(null);

  return (
    <div className="app">
      <PipelineToolbar />
      <PipelineUI />
      <SubmitButton onOutput={setOutput} />
      <OutputPanel output={output} onClear={() => setOutput(null)} />
    </div>
  );
}

export default App;
