import { DraggableNode } from './draggableNode';
import { toolbarNodes } from './nodes/nodeConfig';

export const PipelineToolbar = () => {
    return (
        <div className="toolbar">
            <span className="toolbar-title">Pipeline Builder</span>
            <div className="toolbar-nodes">
                {toolbarNodes.map(({ type, label }) => (
                    <DraggableNode key={type} type={type} label={label} />
                ))}
            </div>
        </div>
    );
};
