def run(node_data, inputs):
    value = inputs.get('input', '')
    mode = node_data.get('mode', 'copy')

    if mode == 'copy':
        return {'out1': value, 'out2': value}
    elif mode == 'alternate':
        return {'out1': value, 'out2': ''}
    elif mode == 'split':
        text = str(value)
        mid = len(text) // 2
        return {'out1': text[:mid], 'out2': text[mid:]}
    else:
        return {'out1': value, 'out2': value}
