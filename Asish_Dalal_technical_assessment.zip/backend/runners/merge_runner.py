def run(node_data, inputs):
    in1 = inputs.get('in1', '')
    in2 = inputs.get('in2', '')
    strategy = node_data.get('strategy', 'concat')

    if strategy == 'concat':
        return f'{in1} {in2}'.strip()
    elif strategy == 'zip':
        return [in1, in2]
    elif strategy == 'average':
        try:
            return (float(in1) + float(in2)) / 2
        except (ValueError, TypeError):
            return f'{in1} {in2}'
    else:
        return f'{in1} {in2}'
