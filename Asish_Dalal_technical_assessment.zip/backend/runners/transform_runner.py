def run(node_data, inputs):
    value = str(inputs.get('input', ''))
    transform = node_data.get('transform', 'uppercase')

    if transform == 'uppercase':
        return value.upper()
    elif transform == 'lowercase':
        return value.lower()
    elif transform == 'reverse':
        return value[::-1]
    elif transform == 'trim':
        return value.strip()
    else:
        return value
