def run(node_data, inputs):
    a = float(inputs.get('a', 0))
    b = float(inputs.get('b', 0))
    operation = node_data.get('operation', '+')

    if operation == '+':
        return a + b
    elif operation == '-':
        return a - b
    elif operation == '*':
        return a * b
    elif operation == '/':
        return a / b if b != 0 else 'Error: Division by zero'
    else:
        return 'Error: Unknown operation'
