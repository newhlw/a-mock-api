def run(node_data, inputs):
    for key in ['value', 'input', 'output', 'response', 'result', 'merged']:
        if key in inputs and inputs[key] is not None:
            return inputs[key]

    for key, val in inputs.items():
        if val is not None:
            return val

    return ''
