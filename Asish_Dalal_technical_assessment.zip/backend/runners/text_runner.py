import re


def run(node_data, inputs):
    text = node_data.get('text', '')

    def replace_var(match):
        var_name = match.group(1)
        if var_name in inputs:
            return str(inputs[var_name])
        return match.group(0)

    result = re.sub(r'\{\{(\w+)\}\}', replace_var, text)
    return result
