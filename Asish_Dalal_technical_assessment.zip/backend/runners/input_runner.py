def run(node_data, inputs):
    return node_data.get('inputName', 'input')
