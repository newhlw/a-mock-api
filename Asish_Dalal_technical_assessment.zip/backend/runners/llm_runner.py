import os
from google import genai


async def run(node_data, inputs):
    api_key = os.getenv('GEMINI_API_KEY', '')
    model = os.getenv('GEMINI_MODEL', 'gemini-2.0-flash')

    if not api_key:
        return 'Error: GEMINI_API_KEY not set in .env file'

    system_prompt = inputs.get('system', 'You are a helpful assistant.')
    user_prompt = inputs.get('prompt', '')

    try:
        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model=model,
            contents=f'{system_prompt}\n\n{user_prompt}',
        )
        return response.text
    except Exception as e:
        return f'Error calling Gemini: {str(e)}'
