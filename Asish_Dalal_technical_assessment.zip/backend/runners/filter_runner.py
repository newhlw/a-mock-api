def run(node_data, inputs):
    value = inputs.get('input', '')
    condition = node_data.get('condition', 'contains')

    try:
        if condition == 'contains':
            result = bool(value)
        elif condition == 'equals':
            result = str(value).strip() != ''
        elif condition == 'greater':
            result = float(value) > 0
        elif condition == 'less':
            result = float(value) < 0
        else:
            result = bool(value)
    except (ValueError, TypeError):
        result = False

    return {'pass': value, 'fail': None} if result else {'pass': None, 'fail': value}
