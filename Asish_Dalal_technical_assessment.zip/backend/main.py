import json
import time
from collections import deque
from dotenv import load_dotenv

load_dotenv()

from fastapi import FastAPI, Form
from fastapi.middleware.cors import CORSMiddleware

from runners import (
    input_runner,
    text_runner,
    llm_runner,
    math_runner,
    filter_runner,
    merge_runner,
    split_runner,
    transform_runner,
    output_runner,
)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

RUNNERS = {
    'customInput': input_runner,
    'text': text_runner,
    'llm': llm_runner,
    'math': math_runner,
    'filter': filter_runner,
    'merge': merge_runner,
    'split': split_runner,
    'transform': transform_runner,
    'customOutput': output_runner,
}


@app.get('/')
def read_root():
    return {'Ping': 'Pong'}


@app.post('/pipelines/parse')
def parse_pipeline(
    nodes: str = Form(...),
    edges: str = Form(...),
):
    nodes_list = json.loads(nodes)
    edges_list = json.loads(edges)

    num_nodes = len(nodes_list)
    num_edges = len(edges_list)

    node_ids = {node['id'] for node in nodes_list}
    adjacency = {node['id']: [] for node in nodes_list}
    in_degree = {node['id']: 0 for node in nodes_list}

    for edge in edges_list:
        src = edge['source']
        tgt = edge['target']
        if src in node_ids and tgt in node_ids:
            adjacency[src].append(tgt)
            in_degree[tgt] += 1

    queue = deque()
    for node_id, degree in in_degree.items():
        if degree == 0:
            queue.append(node_id)

    topo_order = []
    while queue:
        node = queue.popleft()
        topo_order.append(node)
        for neighbor in adjacency[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    is_dag = len(topo_order) == num_nodes

    return {
        'num_nodes': num_nodes,
        'num_edges': num_edges,
        'is_dag': is_dag,
        'topological_order': topo_order,
    }


@app.post('/pipelines/run')
async def run_pipeline(
    nodes: str = Form(...),
    edges: str = Form(...),
):
    start_time = time.time()

    nodes_list = json.loads(nodes)
    edges_list = json.loads(edges)

    node_map = {node['id']: node for node in nodes_list}

    adjacency = {node['id']: [] for node in nodes_list}
    in_degree = {node['id']: 0 for node in nodes_list}

    for edge in edges_list:
        src = edge['source']
        tgt = edge['target']
        if src in node_map and tgt in node_map:
            adjacency[src].append({'target': tgt, 'sourceHandle': edge.get('sourceHandle', ''), 'targetHandle': edge.get('targetHandle', '')})
            in_degree[tgt] += 1

    queue = deque()
    for node_id, degree in in_degree.items():
        if degree == 0:
            queue.append(node_id)

    topo_order = []
    while queue:
        node = queue.popleft()
        topo_order.append(node)
        for neighbor_info in adjacency[node]:
            in_degree[neighbor_info['target']] -= 1
            if in_degree[neighbor_info['target']] == 0:
                queue.append(neighbor_info['target'])

    node_outputs = {}
    final_output = None
    errors = []

    def clean_handle_name(handle_id, node_id):
        if handle_id.startswith(node_id + '-'):
            return handle_id[len(node_id) + 1:]
        return handle_id

    for node_id in topo_order:
        node = node_map[node_id]
        node_type = node['type']
        node_data = node.get('data', {})

        inputs = {}
        for edge in edges_list:
            if edge['target'] == node_id:
                source_id = edge['source']
                target_handle = edge.get('targetHandle', 'input')
                target_key = clean_handle_name(target_handle, node_id)

                if source_id in node_outputs:
                    source_output = node_outputs[source_id]
                    if isinstance(source_output, dict):
                        source_key = clean_handle_name(edge.get('sourceHandle', ''), source_id)
                        if source_key in source_output:
                            inputs[target_key] = source_output[source_key]
                        elif target_key in source_output:
                            inputs[target_key] = source_output[target_key]
                        else:
                            for key, val in source_output.items():
                                if val is not None:
                                    inputs[target_key] = val
                                    break
                    else:
                        inputs[target_key] = source_output

        runner = RUNNERS.get(node_type)
        if runner:
            try:
                import inspect
                if inspect.iscoroutinefunction(runner.run):
                    output = await runner.run(node_data, inputs)
                else:
                    output = runner.run(node_data, inputs)
                node_outputs[node_id] = output

                if node_type == 'customOutput':
                    final_output = output
            except Exception as e:
                errors.append(f'Error in {node_type} ({node_id}): {str(e)}')
                node_outputs[node_id] = f'Error: {str(e)}'
        else:
            errors.append(f'Unknown node type: {node_type}')
            node_outputs[node_id] = f'Error: Unknown node type {node_type}'

    execution_time = round(time.time() - start_time, 2)

    return {
        'success': len(errors) == 0,
        'result': final_output,
        'node_outputs': {k: str(v) for k, v in node_outputs.items()},
        'execution_time': execution_time,
        'errors': errors,
    }
